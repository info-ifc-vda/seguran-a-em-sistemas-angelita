#!/bin/bash

# Manter o container em execução
tail -f /dev/null
